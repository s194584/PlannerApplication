package planner.app;

// Ansvarlig: Christopher
public class ProjectManager extends Employee {

    public ProjectManager(String in) {
        super(in);
    }

    public ProjectManager(User u) {
        super(u.getInitials());
    }









}
