package planner.app;

// Ansvarlig: Christian
public class Admin extends User {

    public Admin(String initials){
        super(initials);
    }
}
