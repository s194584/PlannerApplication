package acceptance_tests;

import planner.app.User;

// Ansvarlig: Andreas
public class UserHelper {
    private User user;

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
