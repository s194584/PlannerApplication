package acceptance_tests;

import planner.app.Project;

// Ansvarlig: Malthe
public class ProjectHelper {
    private Project project;

    public Project getProject() {
        return project;
    }

    public void setProject(Project project) {
        this.project = project;
    }
}
