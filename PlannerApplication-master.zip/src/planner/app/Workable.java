package planner.app;

// Ansvarlig: Andreas
public interface Workable {
    Information getInformation();
}
