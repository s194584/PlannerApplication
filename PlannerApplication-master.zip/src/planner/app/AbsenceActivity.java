package planner.app;

// Ansvarlig: Andreas
public class AbsenceActivity extends Activity {

}
