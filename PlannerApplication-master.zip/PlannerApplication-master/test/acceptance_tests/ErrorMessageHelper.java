package acceptance_tests;

// Ansvarlig: Christopher
public class ErrorMessageHelper {
    private String errorMessage = "";

    public ErrorMessageHelper() {

    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }
}
