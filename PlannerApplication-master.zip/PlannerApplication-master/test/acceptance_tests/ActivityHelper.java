package acceptance_tests;

import planner.app.Activity;

// Ansvarlig: Christopher
public class ActivityHelper {

    private Activity activity;

    public void setActivity(Activity activity) {
        this.activity = activity;
    }

    public Activity getActivity() {
        return activity;
    }
}
