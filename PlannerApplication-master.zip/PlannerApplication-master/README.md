# Instructions
* This is a IntelliJ project, developed with JDK 11 and JavaFX11.
* The resource folder has to be marked as such in project structure.
* To run the application the VM options be sat as follows:
  * --module-path ${PATH_TO_FX11} --add-modules=javafx.controls,javafx.fxml
* To run the AcceptanceTest the VM options must be empty.
